<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<title>::.BSF POLYTECHNIC.::</title>
</head>

<body>
<div id="content">
	<div >
    	<img src="picture/main1.jpg" width="805" height="308"  />
    </div>
    
    <div id="space"></div>
    
    <div id="question">
    	What do you know about BSF POLYTECHNIC ?
    </div>
    
    <div id="space"></div>
    
    <div style="text-indent:40px; text-align:justify">
   	
        WELCOME TO BSF POLYTECHNIC TIGRI CAMP, NEW DELHI
        This institute is being run by the bsf Education Fund under society act 1956.
        The Diploma course in Electronic & Communication Engineering started during Aug' 1974 and it has completed 39 years of its existence        successfully .The Computer Engineering Started in Aug'04. The programme is approved by All
		India Council of Technical Education, New Delhi & affiliated by Board Of Technical Education, New Delhi. This course is being run only for       the wards of BSF personnel as a welfare measure
  </div>
</div><!--end of content -->
</body>
</html>